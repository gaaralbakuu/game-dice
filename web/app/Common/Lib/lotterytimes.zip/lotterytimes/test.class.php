<?php 
namespace Lib\lotterytimes;

class test{

	function test(){
		$name = 'lhc';
		$cjnowtime = cjnowtime($name);
		echo $cjnowtime;
		//echo 'test';
	}
}
 ?>
